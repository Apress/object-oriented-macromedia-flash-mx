
 Object Oriented Macromedia Flash MX
    Published by Apress L.P. 2002
           by William Drol

            12 June, 2002



*-----------------------------------
*
*  Additional Book Info, Questions
* and Comments via Email, and Extra
*   Online Chapter(s) Located at:
*
*      http://www.billdrol.com
*
*-----------------------------------



PROJECTS, FOLDERS, AND SOURCE CODE

All projects described in book are
included in the following folders:

/FlashOOP/Tests
/FlashOOP/Classes
/FlashOOP/Projects
/FlashOOP/Services
/FlashOOP/Services/XmlMenus
/FlashOOP/Services/ServiceManager

Just copy the FlashOOP folder and
everything contained within it to
your desktop. All projects will 
run as is, without any further
installation. Of course you need
Flash MX to edit these projects
(30-day free trial available at
http://www.macromedia.com)



CHAPTER 15 NOTE

The DynamicCode.fla project in 
chapter 15 uses two bitmap images
to represent the trash can symbol.
In this download, you'll notice
a bitmap version AND a vector
version in the Library of
DynamicCode.fla (they both work
the same, but the vector version
is cleaner on screen).

